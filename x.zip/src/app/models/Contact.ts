import { Group } from "./Group";

export class Contact  {
    id?:  number;
    idGroup?: number;
    name?: string;
    phone?: string;
  }